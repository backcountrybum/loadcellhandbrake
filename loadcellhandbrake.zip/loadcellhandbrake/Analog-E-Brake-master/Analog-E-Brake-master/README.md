# Analog-E-Brake
Designed by - AMSTUDIO
YouTube  https://youtu.be/kv0FTpRLFMY

Download Zip.
Copy Joystick folder to Arduino Libraries.
Upload Sketch.

This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
https://creativecommons.org/licenses/by-nc-nd/4.0/

NON-COMMERCIAL PERSONAL USE ONLY COPYRIGHT AMSTUDIO 2018
